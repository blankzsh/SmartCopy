SmartCopy plugin release package 
